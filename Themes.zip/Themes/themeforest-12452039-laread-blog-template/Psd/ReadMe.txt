﻿

LaRead. Designed for Read.


 IT’S AN AWESOME BLOG TO INCREASE USER EXPERIENCE

 We have great several features to increase your perusal pleasure and focusing.
 Everything is far from you except contents that you want to read.

 As long as, you read. Maybe with café, maybe with music…

 -

 Author : Evmet
 Created: 17 October 2016






TEMPLATE FEATURES
====================================================

    Fully customizable
    Flexible and Multipurpose
    Bootstrap layout ready
    Grid lines included
    5 different blog options
    Page and Blocks variations different
    Light and Dark styles
    Free fonts, icons and graphics used
    All icons and shapes are vectoral
    Well organized layers makes it very easy to update
    Named groups and layers
    Documentation included
    51 Fully & Accurately layered .PSD files

    +

    Great Features

    - Banner Mode (2 versions)
    - Quick Read (light, dark)
    - Push Bar (right, fullscreen)


    And much more…




PAGES
====================================================

	About
	Author
	Archive
	Gallery
	Contact
	Account
	404




BLOG STYLES (5)
====================================================

	Large Image -v1
	Large Image -v2
	Medium Image -v1 (sidebar)
	Medium Image -v2
	Masonry
	Masonry with Comment




POST FORMATS (17)
====================================================

	Standart Post
	Image Post
	Gallery Post
	Video Post
	Audio Post
	Quote Post
	Link Post
	Status Post
	Aside Post
	HotNews Post
	Chat Post
	Code Post
	Event/Activity Post
	Twitter Post
	Facebook Post
	Reviews/Rating Post
	Changelog Post





WIDGETS (19)
====================================================

	Search
	Custom Category
	Popular Posts
	Recent Posts
	Recent Comments
	Archive
	Tag
	Newsletter
	Text Widget
	Quote
	Social Icons
	Play Video
	Calendar
	Advertisement
	Twitter
	Facebook
	Instagram
	Flickr
	Dribbble




TYPOGRAPHY
====================================================

	H1-H6
	Hightlight/Dropcap
	Images (left, right, center)
	Blockquotes (pullquote, blockquote)
	Buttons
	Quotes with Rating
	Divider
	Preformatted Text
	Progress
	List (unordered, ordered)
	Table




SHORTCODES
====================================================

	Columns
	Tabs
	Accordion/Toggle Box
	Button
	Notification Box
	Promote Box
	Social Post
	Media (embed)
	Gallery/Slider
	Google Map




PSD FILES
====================================================

 This PSD template has following 51 files.

	01-Large_Image_v1
	   Large_Image_v1-1.psd
	   Large_Image_v1-2.psd
	   Large_Image_v1-3.psd
	   Large_Image_v1-Post_Detail.psd

	02-Large_Image_v2
	   Large_Image_v2-1.psd
	   Large_Image_v2-2.psd
	   Large_Image_v2-3.psd

	03-Medium_Image_v1
	   Medium_Image_v1-1.psd
	   Medium_Image_v1-2.psd
	   Medium_Image_v1-3.psd

	04-Medium_Image_v2
	   Medium_Image_v2-1.psd
	   Medium_Image_v2-2.psd
	   Medium_Image_v2-3.psd

	05-Masonry
	   Masonry_v1.psd
	   Masonry_v2.psd
	   Masonry_v3.psd
	   Masonry_With_Comment.psd

	06-Widgets
	   Widgets.psd

	07-Push_Bar
	   Push_Bar_v1.psd (light)
	   Push_Bar_v2.psd (dark)

	08-Typography
	   Typography_v1.psd
	   Typography_v2.psd
	   Typography_v3.psd
	   Typography_v4.psd

	09-Shortcode
	   Shortcode_v1.psd
	   Shortcode_v2.psd
	   Shortcode_v3.psd
	   Shortcode_v4.psd

	10-About
	   About_v1.psd
	   About_v2.psd

	11-Authors
	   Authors.psd
	   Author_Detail.psd

	12-Archive
	   Archive_v1.psd
	   Archive_v2.psd

	13-Gallery
	   Gallery_v1.psd
	   Gallery_v2.psd
	   Gallery_v3.psd
	   Gallery_v4.psd
	   Gallery_v5-Detail_Light.psd
	   Gallery_v5-Detail_Dark.psd

	14-Contact
	   Contact_v1.psd
	   Contact_v2.psd

	15-404
	   404.psd

	16-Newsletter
	   Newsletter.psd

	17-QuickRead
	   QuickRead-Light.psd
	   QuickRead-Dark.psd

	18-BannerMode
	   BannerMode_v1.psd
	   BannerMode_v2.psd

	19-Account
	   SignIn.psd
	   SignUp.psd

	20-UI
	   Ui.psd


 In the all PSD files, layers are named and grouped. It is so easy to organize them.




SOURCES AND CREDITS
====================================================

 We thank to great artists who give a magic touch to our theme with their unique work so much. 
 Content is king.



 Free Fonts Used

	Raleway
	https://www.google.com/fonts/specimen/Raleway

	Muli
	https://www.google.com/fonts/specimen/Muli

	Sorts Mill Goudy
	https://www.google.com/fonts/specimen/Sorts+Mill+Goudy

	Roboto
	https://www.google.com/fonts/specimen/Roboto

	Roboto Slab
	https://www.google.com/fonts/specimen/Roboto+Slab


 Free Icon Used

	Font Awesome
	http://fontawesome.io/


 Photo Credits

	Unsplash
	http://unsplash.com/

	Anthony James
	https://www.behance.net/gallery/20065757/Alphabetica-Type-Treatm

	Linxspiration
	http://linxspiration.com/

	Maure
	http://cristian1985maure.tumblr.com/

	High Enough to See The Sea
	http://highenoughtoseethesea.tumblr.com/




HELP AND SUPPORT
========================================

 If you have any problem or concern about the product, please don’t hesitate to contact with us. 
 We will help you with satisfaction. < email: support@evmet.net - http://themeforest.net/user/evmet >










 © 2015 Evmet | Pure Passion.


